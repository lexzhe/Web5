package com.intellij.psi.css;

import com.intellij.psi.PsiElement;
import com.intellij.psi.css.impl.util.table.CssCompletionContext;
import com.intellij.psi.css.impl.util.table.CssTableValue;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * @author Eugene.Kudelevsky
 * @deprecated use CssValueDescriptor
 */
@Deprecated
public interface CssPropertyValue extends CssTableValue<CssPropertyValue, Object> {
  boolean isComplete();

  void setComplete(boolean complete);

  @Nullable
  String getRefName();

  void setRefName(@NotNull String refName);

  boolean isValueBelongs(@Nullable PsiElement element);

  @NotNull
  List<? extends CssPropertyValue> getVariants(@NotNull CssCompletionContext context, PsiElement contextElement);

  @NotNull
  List<? extends CssPropertyValue> getDynamicVariants(@NotNull PsiElement contextElement);

  @Override
  boolean isGroup();

  int getMaxCompletionContextLength();

  int getMaxValuesCount();

  boolean isCompleted(CssCompletionContext context);

  int getCompletionCount(CssCompletionContext context);
}
