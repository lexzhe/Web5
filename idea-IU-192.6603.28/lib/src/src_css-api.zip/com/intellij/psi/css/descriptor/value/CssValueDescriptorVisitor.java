package com.intellij.psi.css.descriptor.value;

import org.jetbrains.annotations.NotNull;

public interface CssValueDescriptorVisitor {
  void visitValue(@NotNull CssValueDescriptor value);
}
