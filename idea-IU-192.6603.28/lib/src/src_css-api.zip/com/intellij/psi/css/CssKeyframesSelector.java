package com.intellij.psi.css;

public interface CssKeyframesSelector extends CssSimpleSelector {
}
