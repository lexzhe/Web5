/*
 * Copyright 2000-2017 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
 */
package com.intellij.spring.gutter.groups;

import com.intellij.icons.AllIcons;
import com.intellij.ui.LayeredIcon;
import com.intellij.util.ui.JBUI;
import icons.SpringApiIcons;

import javax.swing.*;

public interface SpringGroupLineMarker {
  default Icon getSpringActionGroupIcon() {
     LayeredIcon icon = JBUI.scale(new LayeredIcon(2));
     icon.setIcon(SpringApiIcons.Gutter.SpringJavaBean, 0, 0, 0);
     icon.setIcon(AllIcons.General.DropdownGutter, 1, 0, 0);
     return icon;
   }
}
