// Copyright 2000-2019 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.xml.beans;

import com.intellij.jam.model.common.CommonModelElement;
import com.intellij.psi.PsiElement;
import com.intellij.spring.model.SpringProfile;
import com.intellij.spring.model.converters.SpringProfileConverter;
import com.intellij.util.xml.Convert;
import com.intellij.util.xml.GenericAttributeValue;
import org.jetbrains.annotations.NotNull;

import java.util.*;

/**
 * @author Sergey Vasiliev
 */
@Convert(SpringProfileConverter.class)
public abstract class SpringDomProfile implements GenericAttributeValue<List<String>>, SpringProfile, CommonModelElement {

  @Override
  public PsiElement getIdentifyingPsiElement() {
    return getXmlElement();
  }

  @NotNull
  @Override
  public Set<String> getNames() {
    final List<String> profileNames = getValue();
    if (profileNames == null) {
      return Collections.singleton(DEFAULT_PROFILE_NAME);
    }

    return new LinkedHashSet<>(profileNames);
  }
}
