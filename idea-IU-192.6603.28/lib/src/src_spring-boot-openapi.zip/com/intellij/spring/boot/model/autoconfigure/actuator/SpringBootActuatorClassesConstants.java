// Copyright 2000-2017 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.boot.model.autoconfigure.actuator;

/**
 * @author Konstantin Aleev
 */
public final class SpringBootActuatorClassesConstants {
  // Spring Boot 1.x
  public static final String MANAGEMENT_CONTEXT_CONFIGURATION =
    "org.springframework.boot.actuate.autoconfigure.ManagementContextConfiguration";

  public static final String MANAGEMENT_CONTEXT_CONFIGURATION_IMPORT_SELECTOR =
    "org.springframework.boot.actuate.autoconfigure.ManagementContextConfigurationsImportSelector";

  // Spring Boot 2.x
  public static final String MANAGEMENT_CONTEXT_CONFIGURATION_SB2 =
    "org.springframework.boot.actuate.autoconfigure.web.ManagementContextConfiguration";

  public static final String MANAGEMENT_CONTEXT_CONFIGURATION_IMPORT_SELECTOR_SB2 =
    "org.springframework.boot.actuate.autoconfigure.web.server.ManagementContextConfigurationImportSelector";
}
