// Copyright 2000-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.boot.application.config.hints;

import com.intellij.openapi.util.TextRange;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiReference;
import com.intellij.util.ProcessingContext;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public abstract class SpringBootHintReferenceProviderBase implements SpringBootHintReferenceProvider {
  @Override
  public final PsiReference[] getReferences(@NotNull PsiElement element,
                                            @NotNull List<TextRange> textRanges,
                                            @NotNull ProcessingContext context) {
    if (!canProcess(element, textRanges, context)) {
      return PsiReference.EMPTY_ARRAY;
    }

    return ContainerUtil.map2Array(textRanges, PsiReference.class, range -> createReference(element, range, context));
  }

  protected boolean canProcess(@NotNull PsiElement element,
                               @NotNull List<TextRange> textRanges,
                               @NotNull ProcessingContext context) {
    return true;
  }

  @NotNull
  protected abstract PsiReference createReference(PsiElement element, TextRange textRange, ProcessingContext context);
}
