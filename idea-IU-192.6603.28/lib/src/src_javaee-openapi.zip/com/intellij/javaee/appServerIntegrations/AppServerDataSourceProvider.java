package com.intellij.javaee.appServerIntegrations;

import com.intellij.database.autoconfig.DataSourceDetector;
import com.intellij.javaee.serverInstances.J2EEServerInstance;
import org.jetbrains.annotations.NotNull;

/**
 * @author gregsh
 */
public interface AppServerDataSourceProvider {
  void loadDataSourcesFromServer(@NotNull J2EEServerInstance instance, @NotNull DataSourceDetector.Builder builder);
}
