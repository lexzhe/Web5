package com.intellij.javaee.context;

public interface DeploymentModelContext {

  boolean isDefaultContextRoot();

  String getContextRoot();
}
