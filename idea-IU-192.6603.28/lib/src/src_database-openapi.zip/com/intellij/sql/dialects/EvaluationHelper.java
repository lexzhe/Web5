package com.intellij.sql.dialects;

import com.intellij.database.DbmsExtension;
import com.intellij.sql.psi.SqlElement;
import org.jetbrains.annotations.NotNull;

/**
 * @author Liudmila Kornilova
 */
public interface EvaluationHelper {
  DbmsExtension<EvaluationHelper> EP = new DbmsExtension<>("com.intellij.sql.evaluationHelper");

  String getQuery(@NotNull String text, @NotNull SqlElement sqlElement);
}
