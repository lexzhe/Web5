package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlUpdatabilityClause extends SqlClause {
}
