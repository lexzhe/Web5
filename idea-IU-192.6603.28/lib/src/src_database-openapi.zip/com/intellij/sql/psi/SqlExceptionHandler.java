package com.intellij.sql.psi;

import com.intellij.util.containers.JBIterable;
import org.jetbrains.annotations.NotNull;

public interface SqlExceptionHandler extends SqlElement {
  @NotNull
  JBIterable<SqlErrorSpec> getErrorSpecs();

  @NotNull
  JBIterable<SqlStatement> getActions();
}
