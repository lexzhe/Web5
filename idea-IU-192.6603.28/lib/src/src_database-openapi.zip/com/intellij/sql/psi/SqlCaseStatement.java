package com.intellij.sql.psi;

public interface SqlCaseStatement extends SqlCaseElement, SqlStatement {
}
