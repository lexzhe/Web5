package com.intellij.sql.psi;

public interface SqlGotoStatement extends SqlJumpStatement {
}