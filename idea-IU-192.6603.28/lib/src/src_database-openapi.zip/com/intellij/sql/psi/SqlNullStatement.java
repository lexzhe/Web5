package com.intellij.sql.psi;

public interface SqlNullStatement extends SqlStatement {
}
